from .invoice import generate

invoice.generate("invoices", "output", "invoices\pythonhow.png", "product_id", "product_name", "amount_purchased", "price_per_unit", "total_price", "Yusuf & Co.")